"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[672],{3691:function(e,r,t){var o=t(5318);r.Z=void 0;var a=o(t(4938)),n=t(5893),i=(0,a.default)((0,n.jsx)("path",{d:"M22 13h-8v-2h8v2zm0-6h-8v2h8V7zm-8 10h8v-2h-8v2zm-2-8v6c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V9c0-1.1.9-2 2-2h6c1.1 0 2 .9 2 2zm-1.5 6-2.25-3-1.75 2.26-1.25-1.51L3.5 15h7z"}),"ArtTrack");r.Z=i},6857:function(e,r,t){var o=t(5318);r.Z=void 0;var a=o(t(4938)),n=t(5893),i=(0,a.default)((0,n.jsx)("path",{d:"M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"}),"AttachMoney");r.Z=i},8837:function(e,r,t){var o=t(5318);r.Z=void 0;var a=o(t(4938)),n=t(5893),i=(0,a.default)((0,n.jsx)("path",{d:"M11.5 2C6.81 2 3 5.81 3 10.5S6.81 19 11.5 19h.5v3c4.86-2.34 8-7 8-11.5C20 5.81 16.19 2 11.5 2zm1 14.5h-2v-2h2v2zm0-3.5h-2c0-3.25 3-3 3-5 0-1.1-.9-2-2-2s-2 .9-2 2h-2c0-2.21 1.79-4 4-4s4 1.79 4 4c0 2.5-3 2.75-3 5z"}),"ContactSupport");r.Z=i},3468:function(e,r,t){var o=t(5318);r.Z=void 0;var a=o(t(4938)),n=t(5893),i=(0,a.default)((0,n.jsx)("path",{d:"M12 11.55C9.64 9.35 6.48 8 3 8v11c3.48 0 6.64 1.35 9 3.55 2.36-2.19 5.52-3.55 9-3.55V8c-3.48 0-6.64 1.35-9 3.55zM12 8c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3z"}),"LocalLibrary");r.Z=i},4672:function(e,r,t){t.r(r),t.d(r,{default:function(){return le}});var o=t(5893),a=t(7294),n=t(5675),i=t.n(n),s=t(7357),l=t(6886),c=t(1496),d=t(7948),u=t(5861),f=t(3366),h=t(7462),m=t(6010),b=t(7192),v=t(917),p=t(8216),x=t(3616),g=t(8979),y=t(6087);function Z(e){return(0,g.Z)("MuiCircularProgress",e)}(0,y.Z)("MuiCircularProgress",["root","determinate","indeterminate","colorPrimary","colorSecondary","svg","circle","circleDeterminate","circleIndeterminate","circleDisableShrink"]);const k=["className","color","disableShrink","size","style","thickness","value","variant"];let j,w,S,C,P=e=>e;const z=44,M=(0,v.F4)(j||(j=P`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`)),$=(0,v.F4)(w||(w=P`
  0% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: 0;
  }

  50% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -15px;
  }

  100% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -125px;
  }
`)),D=(0,c.ZP)("span",{name:"MuiCircularProgress",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.root,r[t.variant],r[`color${(0,p.Z)(t.color)}`]]}})((({ownerState:e,theme:r})=>(0,h.Z)({display:"inline-block"},"determinate"===e.variant&&{transition:r.transitions.create("transform")},"inherit"!==e.color&&{color:r.palette[e.color].main})),(({ownerState:e})=>"indeterminate"===e.variant&&(0,v.iv)(S||(S=P`
      animation: ${0} 1.4s linear infinite;
    `),M))),I=(0,c.ZP)("svg",{name:"MuiCircularProgress",slot:"Svg",overridesResolver:(e,r)=>r.svg})({display:"block"}),R=(0,c.ZP)("circle",{name:"MuiCircularProgress",slot:"Circle",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.circle,r[`circle${(0,p.Z)(t.variant)}`],t.disableShrink&&r.circleDisableShrink]}})((({ownerState:e,theme:r})=>(0,h.Z)({stroke:"currentColor"},"determinate"===e.variant&&{transition:r.transitions.create("stroke-dashoffset")},"indeterminate"===e.variant&&{strokeDasharray:"80px, 200px",strokeDashoffset:0})),(({ownerState:e})=>"indeterminate"===e.variant&&!e.disableShrink&&(0,v.iv)(C||(C=P`
      animation: ${0} 1.4s ease-in-out infinite;
    `),$)));var N=a.forwardRef((function(e,r){const t=(0,x.Z)({props:e,name:"MuiCircularProgress"}),{className:a,color:n="primary",disableShrink:i=!1,size:s=40,style:l,thickness:c=3.6,value:d=0,variant:u="indeterminate"}=t,v=(0,f.Z)(t,k),g=(0,h.Z)({},t,{color:n,disableShrink:i,size:s,thickness:c,value:d,variant:u}),y=(e=>{const{classes:r,variant:t,color:o,disableShrink:a}=e,n={root:["root",t,`color${(0,p.Z)(o)}`],svg:["svg"],circle:["circle",`circle${(0,p.Z)(t)}`,a&&"circleDisableShrink"]};return(0,b.Z)(n,Z,r)})(g),j={},w={},S={};if("determinate"===u){const e=2*Math.PI*((z-c)/2);j.strokeDasharray=e.toFixed(3),S["aria-valuenow"]=Math.round(d),j.strokeDashoffset=`${((100-d)/100*e).toFixed(3)}px`,w.transform="rotate(-90deg)"}return(0,o.jsx)(D,(0,h.Z)({className:(0,m.Z)(y.root,a),style:(0,h.Z)({width:s,height:s},w,l),ownerState:g,ref:r,role:"progressbar"},S,v,{children:(0,o.jsx)(I,{className:y.svg,ownerState:g,viewBox:"22 22 44 44",children:(0,o.jsx)(R,{className:y.circle,style:j,ownerState:g,cx:z,cy:z,r:(z-c)/2,fill:"none",strokeWidth:c})})}))})),B=t(1796),L=t(2734);function F(e){return(0,g.Z)("MuiLinearProgress",e)}var O=(0,y.Z)("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]);const q=["className","color","value","valueBuffer","variant"];let E,A,T,H,V,W,_=e=>e;const X=(0,v.F4)(E||(E=_`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`)),G=(0,v.F4)(A||(A=_`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`)),U=(0,v.F4)(T||(T=_`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`)),J=(e,r)=>"inherit"===r?"currentColor":"light"===e.palette.mode?(0,B.$n)(e.palette[r].main,.62):(0,B._j)(e.palette[r].main,.5),K=(0,c.ZP)("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.root,r[`color${(0,p.Z)(t.color)}`],r[t.variant]]}})((({ownerState:e,theme:r})=>(0,h.Z)({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},backgroundColor:J(r,e.color)},"inherit"===e.color&&"buffer"!==e.variant&&{backgroundColor:"none","&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}},"buffer"===e.variant&&{backgroundColor:"transparent"},"query"===e.variant&&{transform:"rotate(180deg)"}))),Q=(0,c.ZP)("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.dashed,r[`dashedColor${(0,p.Z)(t.color)}`]]}})((({ownerState:e,theme:r})=>{const t=J(r,e.color);return(0,h.Z)({position:"absolute",marginTop:0,height:"100%",width:"100%"},"inherit"===e.color&&{opacity:.3},{backgroundImage:`radial-gradient(${t} 0%, ${t} 16%, transparent 42%)`,backgroundSize:"10px 10px",backgroundPosition:"0 -23px"})}),(0,v.iv)(H||(H=_`
    animation: ${0} 3s infinite linear;
  `),U)),Y=(0,c.ZP)("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.bar,r[`barColor${(0,p.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&r.bar1Indeterminate,"determinate"===t.variant&&r.bar1Determinate,"buffer"===t.variant&&r.bar1Buffer]}})((({ownerState:e,theme:r})=>(0,h.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",backgroundColor:"inherit"===e.color?"currentColor":r.palette[e.color].main},"determinate"===e.variant&&{transition:"transform .4s linear"},"buffer"===e.variant&&{zIndex:1,transition:"transform .4s linear"})),(({ownerState:e})=>("indeterminate"===e.variant||"query"===e.variant)&&(0,v.iv)(V||(V=_`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    `),X))),ee=(0,c.ZP)("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.bar,r[`barColor${(0,p.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&r.bar2Indeterminate,"buffer"===t.variant&&r.bar2Buffer]}})((({ownerState:e,theme:r})=>(0,h.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left"},"buffer"!==e.variant&&{backgroundColor:"inherit"===e.color?"currentColor":r.palette[e.color].main},"inherit"===e.color&&{opacity:.3},"buffer"===e.variant&&{backgroundColor:J(r,e.color),transition:"transform .4s linear"})),(({ownerState:e})=>("indeterminate"===e.variant||"query"===e.variant)&&(0,v.iv)(W||(W=_`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
    `),G)));var re=a.forwardRef((function(e,r){const t=(0,x.Z)({props:e,name:"MuiLinearProgress"}),{className:a,color:n="primary",value:i,valueBuffer:s,variant:l="indeterminate"}=t,c=(0,f.Z)(t,q),d=(0,h.Z)({},t,{color:n,variant:l}),u=(e=>{const{classes:r,variant:t,color:o}=e,a={root:["root",`color${(0,p.Z)(o)}`,t],dashed:["dashed",`dashedColor${(0,p.Z)(o)}`],bar1:["bar",`barColor${(0,p.Z)(o)}`,("indeterminate"===t||"query"===t)&&"bar1Indeterminate","determinate"===t&&"bar1Determinate","buffer"===t&&"bar1Buffer"],bar2:["bar","buffer"!==t&&`barColor${(0,p.Z)(o)}`,"buffer"===t&&`color${(0,p.Z)(o)}`,("indeterminate"===t||"query"===t)&&"bar2Indeterminate","buffer"===t&&"bar2Buffer"]};return(0,b.Z)(a,F,r)})(d),v=(0,L.Z)(),g={},y={bar1:{},bar2:{}};if("determinate"===l||"buffer"===l)if(void 0!==i){g["aria-valuenow"]=Math.round(i),g["aria-valuemin"]=0,g["aria-valuemax"]=100;let e=i-100;"rtl"===v.direction&&(e=-e),y.bar1.transform=`translateX(${e}%)`}else 0;if("buffer"===l)if(void 0!==s){let e=(s||0)-100;"rtl"===v.direction&&(e=-e),y.bar2.transform=`translateX(${e}%)`}else 0;return(0,o.jsxs)(K,(0,h.Z)({className:(0,m.Z)(u.root,a),ownerState:d,role:"progressbar"},g,{ref:r},c,{children:["buffer"===l?(0,o.jsx)(Q,{className:u.dashed,ownerState:d}):null,(0,o.jsx)(Y,{className:u.bar1,ownerState:d,style:y.bar1}),"determinate"===l?null:(0,o.jsx)(ee,{className:u.bar2,ownerState:d,style:y.bar2})]}))})),te=t(3691),oe=t(6857),ae=t(3468),ne=t(8837),ie=[{title:"Easy Accessable",description:"Seamlessly reach your learning goals with our user-friendly platform, ensuring effortless navigation and immediate access to enriching educational content.",icon:(0,o.jsx)(te.Z,{})},{title:"More Affordable Cost",description:"Unlock your learning potential without breaking the bank. Benefit from budget-friendly options tailored to your educational journey.",icon:(0,o.jsx)(oe.Z,{})},{title:"Flexible Study Time",description:"Tailor your learning to fit your schedule. Enjoy the freedom to study whenever and wherever it suits you best.",icon:(0,o.jsx)(ae.Z,{})},{title:"Consultation With Mentor",description:"Gain personalized guidance from experienced mentors. Elevate your learning journey with one-on-one support and valuable insights.",icon:(0,o.jsx)(ne.Z,{})}];function se(e,r,t){return r in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}(0,c.ZP)(re,{shouldForwardProp:function(e){return"color"!==e}})((function(e){var r,t=e.theme,o=e.order;return se(r={height:6,borderRadius:5},"&.".concat(O.colorPrimary),{backgroundColor:t.palette.grey[200]}),se(r,"& .".concat(O.bar),function(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{},o=Object.keys(t);"function"===typeof Object.getOwnPropertySymbols&&(o=o.concat(Object.getOwnPropertySymbols(t).filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable})))),o.forEach((function(r){se(e,r,t[r])}))}return e}({borderRadius:5},1===o&&{backgroundColor:"#f303ff"},2===o&&{backgroundColor:"#26e8bd"},3===o&&{backgroundColor:"#0063ff"})),r}));var le=function(){return(0,o.jsx)(s.Z,{id:"feature",sx:{py:{xs:10,md:14},backgroundColor:"background.paper"},children:(0,o.jsx)(d.Z,{children:(0,o.jsxs)(l.ZP,{container:!0,spacing:3,children:[(0,o.jsx)(l.ZP,{item:!0,xs:12,md:5,children:(0,o.jsxs)(s.Z,{sx:{position:"relative"},children:[(0,o.jsx)(i(),{src:"/images/home-feature.png",width:650,height:678,quality:97,alt:"Feature img"}),(0,o.jsx)(s.Z,{sx:{position:"absolute",bottom:-12,left:{xs:0,md:-24},boxShadow:2,borderRadius:1,px:2.2,py:2,zIndex:1,backgroundColor:"background.paper",textAlign:"center"},children:(0,o.jsxs)(s.Z,{sx:{position:"relative",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"},children:[(0,o.jsx)(u.Z,{sx:{fontWeight:600,lineHeight:1},children:"Study Now"}),(0,o.jsx)(u.Z,{variant:"subtitle1",sx:{mb:1,color:"text.disabled"},children:"Travel Latter"}),(0,o.jsxs)(s.Z,{sx:{height:85,width:85,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"},children:[(0,o.jsx)(u.Z,{variant:"h4",sx:{color:"#32dc88"},children:"95%"}),(0,o.jsx)(N,{sx:{position:"absolute",color:"divider"},thickness:2,variant:"determinate",value:85,size:85}),(0,o.jsx)(N,{disableShrink:!0,thickness:2,variant:"determinate",value:75,size:85,sx:{transform:"rotate(96deg) !important",color:"#32dc88",position:"absolute"}})]})]})})]})}),(0,o.jsxs)(l.ZP,{item:!0,xs:12,md:7,children:[(0,o.jsxs)(u.Z,{component:"h2",sx:{position:"relative",fontSize:{xs:40,md:50},ml:{xs:0,md:4},mt:2,mb:3,lineHeight:1,fontWeight:"bold"},children:["Make your"," ",(0,o.jsxs)(u.Z,{component:"mark",sx:{position:"relative",color:"primary.main",fontSize:"inherit",fontWeight:"inherit",backgroundColor:"unset"},children:["Learning ",(0,o.jsx)("br",{}),(0,o.jsx)(s.Z,{sx:{position:"absolute",top:{xs:20,md:28},transform:"rotate(3deg)",left:2,"& img":{width:{xs:140,md:175},height:"auto"}},children:(0,o.jsx)("img",{src:"/images/headline-curve.svg",alt:"Headline curve"})})]}),"Enjoyable"]}),(0,o.jsx)(u.Z,{sx:{color:"text.secondary",mb:2,ml:{xs:0,md:4}},children:"Set the way of learning according to your wishes with some of the benefits that you get us, so you on enjoy the lessons that we provide."}),(0,o.jsx)(l.ZP,{container:!0,spacing:2,sx:{ml:{xs:0,md:2}},children:ie.map((function(e,r){var t=e.title,a=e.description,n=e.icon;return(0,o.jsx)(l.ZP,{item:!0,xs:12,md:6,children:(0,o.jsxs)(s.Z,{sx:{px:2,py:1.5,boxShadow:1,borderRadius:4,display:"flex",alignItems:"center"},children:[(0,o.jsx)(s.Z,{sx:{mr:1,backgroundColor:"primary.main",borderRadius:"50%",height:36,width:36,display:"flex",alignItems:"center",justifyContent:"center",color:"primary.contrastText","& svg":{fontSize:20}},children:n}),(0,o.jsxs)(s.Z,{sx:{display:"flex",flex:1,flexDirection:"column"},children:[(0,o.jsx)(u.Z,{variant:"h6",sx:{fontSize:"1rem",mb:1,color:"secondary.main"},children:t}),(0,o.jsx)(u.Z,{sx:{lineHeight:1.3,color:"text.secondary"},variant:"subtitle1",children:a})]})]})},String(r))}))})]})]})})})}}}]);